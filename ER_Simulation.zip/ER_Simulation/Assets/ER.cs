using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ER : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        EmerygencyRoomQueue erQueue = new EmerygencyRoomQueue();
        erQueue.AdmitPatient(new Patient("John", 56, "Heart Attack"));
        erQueue.AdmitPatient(new Patient("Alex", 65, "Broken Leg"));

        erQueue.PeekNextPatient();
        erQueue.TreatPatient();
        erQueue.PeekNextPatient();
        erQueue.TreatPatient();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

public class Patient
{
    public string name;
    public int age;
    public string condition;

    public Patient(string name, int age, string condition)
    {
        this.name = name;
        this.age = age;
        this.condition = condition;
    }

    public override string ToString()
    {
        return $"{name}, {age}, condition: {condition}";
    }
}

public class EmerygencyRoomQueue
{
    private Queue<Patient> patients = new Queue<Patient>();

    public void AdmitPatient(Patient patient)
    {
        patients.Enqueue(patient);
        Debug.Log(patient.name + ", " + patient.age + " admitted!");
    }

    public void TreatPatient()
    {

        if (patients.Count > 0)
        {
            Patient treatedPatient = patients.Dequeue();
            Debug.Log(treatedPatient.name + " has been treated!");
        }
        else
        {
            Debug.Log("No patient to be treated!");
        }
    }

    public void PeekNextPatient()
    {
        if (patients.Count > 0)
        {
            Patient nextPatient = patients.Peek();
            Debug.Log(nextPatient.name + ", " + nextPatient.age + " is next!");
        }
        else
        {
            Debug.Log("No patient to be treated!");
        }
    }

}

//Lab Activities for you:

//Question One:
//Develop another ER with priority queue
//Patients have some priority, e.g. heart attack has higher priority than a vaccination
//Pations with higher priority are treated first.
//If there are patients with the same priority, then use FIFO strategy.


//Question Two:
//Use queue to simulate aircraft takeoffs at an airport.
//The simulation involves several aspects:
// - Scheduling aircraft for takeoff
// - Managing the takeoff queue
// - Ensuring that the aircrafts are allowed to takeoff in the order they scheduled for
//Note: You need to use FIFO structure, i.e Queue

